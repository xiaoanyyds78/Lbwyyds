---
name: webprojectxiaoan
description: 处理 webprojectxiaoan / webProject_xiaoan 高级网页设计课堂实践项目时使用。当用户要求修改或新增页面、调整样式、梳理 html/css/font 目录结构、理解 柳博文 的课堂实践约定（原生 HTML/CSS/JS、不使用 cdn、中文文件名与中文内容）时使用。Use when working on the webprojectxiaoan course web-design project: index.html, flex布局复习, svg, iconfont.
---

# webprojectxiaoan 高级网页设计课堂实践

柳博文《高级网页设计》课堂实践项目（王垚授课）。这是由学生提交到 Gitee 仓库
`neusoft_wangyao_jsj/webprojectxiaoan` 的原始 HTML/CSS/JS 项目，全部为原生代码。

## 项目定位

- 学员：柳博文（学号 24002120602）
- 主题：王垚的《高级网页设计》课堂实践，首页为课堂目录（index.html）
- 技术约束：**原生 HTML / CSS / JavaScript，不使用 CDN，所有资源本地化**

## 目录结构

```
24002120602-柳博文/            # 提交在仓库中的根目录
├── index.html                  # 课堂目录首页，链接所有实践页面
├── flex布局复习.html           # 实践一：Flex 布局
├── svg.html                    # 实践三：SVG 图标交互
├── css/
│   ├── flex.css                # Flex 练习样式
│   └── svg.css                 # SVG 页面样式
├── font/                       # 本地 iconfont 资源
│   ├── demo_index.html         # iconfont 三种引入方式演示（Unicode / Font class / Symbol）
│   └── iconfont.*              # css / js / json / ttf / woff / woff2
├── .gitignore                  # 忽略编译产物（bin、swf、air 等）
└── .opencode/skills/           # opencode 技能
```

## 约定与注意事项

1. **不使用 CDN**：字体图标、图片、视频全部引用本地文件（`font/`）。
   注意 `svg.html` 的 symbol 脚本目前仍链接线上 alicdn（`at.alicdn.com/...`），如需本地复现可改用 `font/iconfont.js`。
2. **中文文件名**：页面与样式文件名为中文（如 `flex布局复习.html`、`首页.css`）。
   修改或新增页面时保持该命名习惯，引用路径需与文件名完全一致。
3. **页面编码**：`<meta charset="UTF-8">`。
4. **index.html 目录**：新增实践页面后，应在 `index.html` 的 `.lesson-grid`
   中补充对应的 `.lesson-card`（编号、标题、简介、链接），并保持页脚署名
   「柳博文的《高级网页设计》课堂实践」。
5. **iconfont**：图标资源位于 `font/`，页面中已按演示文档的 Font class / Symbol
   方式接入，改动时保持本地引用。
6. **样式规范**：index.html 使用 CSS 自定义属性（`var(--teal)`、`var(--ink)` 等）
   定义主题色；各子页面样式独立放在对应 css 文件中。

## 常见任务

- 新增课堂实践页面：创建 `xxx.html`（原生三件套），样式写入 `css/`，并在
  `index.html` 课堂目录添加卡片链接。
- 修改样式：遵循现有 CSS 变量与配色，移动端断点参考 index.html 的
  `@media (max-width: 680px)`。
- 查看与调试：直接用浏览器打开对应 html 文件即可，无需构建步骤。