# 提示词记录（LBW_prompt.md）

> 规则：每次执行前，将本次提示词以「附加」方式写入本文件，不覆盖历史内容。
> 每条记录包含：时间、使用的模型、提示词原文。

---

## 记录 #1

- **时间**：2026-10-23 13:47:10 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
设置规则：从现在开始，所有CSS类名，id名、js变量都以wy_开始，所有的提示词都在执行之前写入文件LBW_prompt.md，以附加的方式写入，不覆盖之前的内容，写入的内容包括时间、使用的模型、提示词内容。
```

---

## 记录 #2

- **时间**：2026-10-23 13:47:39 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
好的，执行吧
```

---

## 记录 #3

- **时间**：2026-10-23 13:51:19 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
设置规则：所有新建的html文件加入超链接入口到首页index.html
```

---

## 记录 #4

- **时间**：2026-10-23 13:54:37 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
使用当前目录下skills文件夹中的frontend-designskill做两个html网页iconfont-1.html,inconfont-2.html，使得页面具有艺术品牌的样式。分别显示font awesome图标和lucide图标，前者使用字体图标的方式，后者使用svg的方式，相关的cdn文件下载到本目录下的cdn目录。
```

---

## 记录 #5

- **时间**：2026-10-23 13:56:10 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
好的，按这个方案开始吧
```

---

## 记录 #6

- **时间**：2026-10-28 14:30:33 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
`d:\网页设计/实践\starter-level1.html`把这个的JS补全
```

---

## 记录 #7

- **时间**：2026-11-03 21:08:14 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
创建技能skill：提交到github，将本项目提交commit并push到`https://github.com/xiaoanyyds78/Lbwyyds.git`，使用已设置公钥。
```

---

## 记录 #8

- **时间**：2026-11-03 21:15:16 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
帮我创建一个公钥
```

---

## 记录 #9

- **时间**：2026-11-03 21:15:51 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
已添加，请推送 main 分支到 github.com/xiaoanyyds78/Lbwyyds
```

---

## 记录 #10

- **时间**：2026-11-03 21:18:09 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
好的，再试一次
```

---

## 记录 #11

- **时间**：2026-11-03 21:21:34 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
好的，执行吧
```

---

## 记录 #12

- **时间**：2026-11-04 13:33:41 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
修改规则文件AGENTS.md，在新建html文件时加入注释，注释包括：柳博文，建立时间，使用大模型，功能名称。在js部分函数加上函数主要实现功能的注释。
```

---

## 记录 #13

- **时间**：2026-11-04 13:37:48 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
请给我新进一个html文件，显示tab选项卡，选项卡分别为：国内新闻，省内新闻，国际新闻
```

---

## 记录 #14

- **时间**：2026-11-04 13:44:29 (Asia/Shanghai)
- **模型**：DeepSeek-V4.1-Flash
- **提示词内容**：

```text
选项卡还包括最新新闻，国内新闻设置为默认选项。JS文件单独放在JS文件夹中，外部引用。要求js中的tab选项卡可复用，实现代码中的包含监听事件、先清除所有选项卡的选中状态，然后再设置当前元素的选中状态。
```

---
