/**
 * @file tabs.js
 * @author 柳博文
 * @created 2026-11-04
 * @model DeepSeek-V4.1-Flash
 * @description 可复用的 Tab 选项卡组件：自动绑定页面上所有 .wy_tabs 容器，
 *              支持点击与键盘切换，切换时先清除全部选项卡的选中状态，再设置当前项。
 *
 * 使用方式（HTML 结构约定）：
 *   <nav class="wy_tabs" role="tablist">
 *     <button class="wy_tab" role="tab" aria-controls="wy_panelA" aria-selected="true">A</button>
 *     <button class="wy_tab" role="tab" aria-controls="wy_panelB" aria-selected="false" tabindex="-1">B</button>
 *   </nav>
 *   <section class="wy_panel wy_is-active" id="wy_panelA" role="tabpanel">...</section>
 *   <section class="wy_panel" id="wy_panelB" role="tabpanel">...</section>
 *
 * 只需引入本文件，无需写任何初始化代码；也可手动调用 wy_initTabs(容器元素)。
 */
(function (wy_global, wy_doc) {
  "use strict";

  var wy_ACTIVE_CLASS = "wy_is-active";

  /**
   * 初始化单个选项卡容器：读取默认选中项、绑定点击与键盘事件、切换到默认项
   * @param {HTMLElement} wy_root 带 .wy_tabs 类（或 role="tablist"）的容器
   * @returns {boolean} 是否完成初始化（已初始化过的容器返回 false）
   */
  function wy_initTabs(wy_root) {
    if (!wy_root || wy_root.getAttribute("data-wy_tabs-ready") === "true") {
      return false;
    }
    wy_root.setAttribute("data-wy_tabs-ready", "true");

    var wy_tabs = Array.prototype.slice.call(wy_root.querySelectorAll(".wy_tab"));

    // 按 aria-controls 关联每个选项卡对应的面板，找不到则忽略该面板
    var wy_panels = wy_tabs.map(function (wy_tab) {
      return wy_doc.getElementById(wy_tab.getAttribute("aria-controls"));
    });

    // 默认选中：取 HTML 上 aria-selected="true" 的那一项，缺省用第一项
    var wy_defaultIndex = 0;
    wy_tabs.forEach(function (wy_tab, wy_index) {
      if (wy_tab.getAttribute("aria-selected") === "true") {
        wy_defaultIndex = wy_index;
      }
    });

    /**
     * 切换到指定选项卡：先清除所有选项卡的选中状态，再设置当前元素的选中状态
     * @param {number} wy_index 目标选项卡序号
     */
    function wy_activate(wy_index) {
      if (wy_index < 0 || wy_index >= wy_tabs.length) {
        return;
      }

      // 第一步：清除全部选项卡的选中状态，并隐藏所有面板
      wy_tabs.forEach(function (wy_tab, wy_i) {
        wy_tab.setAttribute("aria-selected", "false");
        wy_tab.setAttribute("tabindex", "-1");
        if (wy_panels[wy_i]) {
          wy_panels[wy_i].classList.remove(wy_ACTIVE_CLASS);
          wy_panels[wy_i].setAttribute("aria-hidden", "true");
        }
      });

      // 第二步：设置当前选项卡为选中状态，并显示对应面板
      var wy_targetTab = wy_tabs[wy_index];
      var wy_targetPanel = wy_panels[wy_index];
      wy_targetTab.setAttribute("aria-selected", "true");
      wy_targetTab.setAttribute("tabindex", "0");
      if (wy_targetPanel) {
        wy_targetPanel.classList.add(wy_ACTIVE_CLASS);
        wy_targetPanel.removeAttribute("aria-hidden");
      }
    }

    /**
     * 从点击目标向上查找所属的选项卡，并返回其序号
     * @param {HTMLElement} wy_target 事件目标
     * @returns {number} 选项卡序号，未命中返回 -1
     */
    function wy_findIndex(wy_target) {
      var wy_tab = wy_target.closest(".wy_tab");
      if (!wy_tab) {
        return -1;
      }
      return wy_tabs.indexOf(wy_tab);
    }

    /**
     * 点击监听：点击某个选项卡后切换到该选项卡
     * @param {MouseEvent} wy_event 鼠标事件
     */
    function wy_onClick(wy_event) {
      var wy_index = wy_findIndex(wy_event.target);
      if (wy_index >= 0) {
        wy_activate(wy_index);
      }
    }

    /**
     * 键盘监听：左右方向键循环切换，Home / End 跳到首尾，并同步移动焦点
     * @param {KeyboardEvent} wy_event 键盘事件
     */
    function wy_onKeydown(wy_event) {
      var wy_index = wy_findIndex(wy_event.target);
      if (wy_index < 0) {
        return;
      }

      var wy_next = null;
      if (wy_event.key === "ArrowRight") {
        wy_next = (wy_index + 1) % wy_tabs.length;
      } else if (wy_event.key === "ArrowLeft") {
        wy_next = (wy_index - 1 + wy_tabs.length) % wy_tabs.length;
      } else if (wy_event.key === "Home") {
        wy_next = 0;
      } else if (wy_event.key === "End") {
        wy_next = wy_tabs.length - 1;
      }

      if (wy_next === null) {
        return;
      }
      wy_event.preventDefault();
      wy_activate(wy_next);
      wy_tabs[wy_next].focus();
    }

    // 事件监听：在容器上做事件委托，容器内任意选项卡都生效
    wy_root.addEventListener("click", wy_onClick);
    wy_root.addEventListener("keydown", wy_onKeydown);

    // 进入页面时按 HTML 上的 aria-selected 呈现默认选项
    wy_activate(wy_defaultIndex);

    return true;
  }

  /**
   * 自动初始化页面上所有选项卡容器，页面中有多少组 Tab 就初始化多少组
   * @returns {number} 本次初始化的容器数量
   */
  function wy_initAllTabs() {
    var wy_containers = wy_doc.querySelectorAll(".wy_tabs, [role='tablist']");
    var wy_count = 0;
    Array.prototype.forEach.call(wy_containers, function (wy_container) {
      if (wy_initTabs(wy_container)) {
        wy_count++;
      }
    });
    return wy_count;
  }

  // 暴露给外部，便于在动态插入的 DOM 上手动初始化
  wy_global.wy_initTabs = wy_initTabs;

  // DOM 就绪后自动初始化；脚本放在 body 末尾时可直接执行
  if (wy_doc.readyState === "loading") {
    wy_doc.addEventListener("DOMContentLoaded", wy_initAllTabs);
  } else {
    wy_initAllTabs();
  }
})(window, document);
